# Nova Launcher MB — Android alpha source

Nova Launcher MB is intended to become a custom Android launcher for Minecraft: Java Edition, with version selection, profiles/modpacks, offline nickname option, themes, and editable touch controls.

## Architecture decision

The recommended base for real game launching is **Amethyst-Android**, the active successor project identified by the archived PojavLauncher repository. Its Android project contains the runtime and native launch integration needed for Java Edition. It is not a simple dependency that can be dropped into this Compose app; the practical route is to first build/rebrand the upstream app, preserve its engine, and then integrate Nova features gradually.

Read:
- `ARCHITECTURE_AND_LICENSE.md` — architecture, licensing and distribution checklist.
- `NEXT_STEPS.md` — milestones and device verification plan.

Upstream: https://github.com/AngelAuraMC/Amethyst-Android
Upstream build docs use a recursive clone and `:app_pojavlauncher:assembleDebug`.

## What this prototype currently does

- Jetpack Compose navigation and a basic Nova MB interface.
- Retrieves the official Mojang version manifest.
- Saves the offline nickname and theme preference.
- Demonstrates a session-only profiles list and a mock touch-control editor.
- Includes a GitHub Actions workflow to build this prototype.

## What it does NOT do yet

This prototype does **not** download/install all Minecraft game files, start a JVM, render Minecraft, install Fabric/Forge/NeoForge, import `.mrpack`, or provide a real in-game input overlay. The Play button is a placeholder. The separate Amethyst engine must be integrated and tested before these are advertised as working.

## Build this prototype

Push the contents of this folder to a GitHub repository named `nova-launchermb`, open **Actions**, run **Build Nova Launcher MB**, then download the `nova-launchermb-debug-apk` artifact from the successful workflow. This only builds the UI prototype, not the finished Java Edition launcher.
