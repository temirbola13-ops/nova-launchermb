package app.novalaunchermb

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

private val Purple = Color(0xFF8B6CFF)
private val Dark = Color(0xFF11121A)
private val Panel = Color(0xFF1D1F2B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("nova_mb", MODE_PRIVATE)
        setContent {
            var darkMode by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
            MaterialTheme(colorScheme = if (darkMode) darkColorScheme(primary=Purple, background=Dark, surface=Panel) else lightColorScheme(primary=Purple)) {
                NovaApp(
                    initialNick = prefs.getString("nick", "Player") ?: "Player",
                    initialTheme = darkMode,
                    onNickSave = { prefs.edit().putString("nick", it).apply() },
                    onTheme = { darkMode = it; prefs.edit().putBoolean("dark", it).apply() }
                )
            }
        }
    }
}

@Composable
private fun NovaApp(initialNick: String, initialTheme: Boolean, onNickSave: (String)->Unit, onTheme: (Boolean)->Unit) {
    var page by remember { mutableStateOf("Главная") }
    var nick by remember { mutableStateOf(initialNick) }
    var selectedVersion by remember { mutableStateOf("1.21.11") }
    var versions by remember { mutableStateOf(listOf("1.21.11", "1.21.10", "1.21.9")) }
    var versionType by remember { mutableStateOf("release") }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Готов к настройке") }
    var dark by remember { mutableStateOf(initialTheme) }
    var packName by remember { mutableStateOf("") }
    var packs by remember { mutableStateOf(listOf("Чистый Minecraft")) }
    var buttons by remember { mutableStateOf(listOf("Вперёд", "Назад", "Влево", "Вправо", "Прыжок", "Инвентарь")) }
    var customColor by remember { mutableStateOf("Фиолетовый") }

    Scaffold(containerColor = MaterialTheme.colorScheme.background, topBar = {
        Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal=18.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
            Text("NOVA", color=Purple, fontSize=25.sp, fontWeight=FontWeight.Black)
            Text(" LAUNCHER MB", fontSize=13.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.weight(1f)); Text("ALPHA", color=Purple, fontSize=11.sp, fontWeight=FontWeight.Bold)
        }
    }, bottomBar = {
        NavigationBar(containerColor=Panel) {
            listOf("Главная" to Icons.Default.Home, "Версии" to Icons.Default.Download, "Сборки" to Icons.Default.Inventory2, "Управление" to Icons.Default.Gamepad, "Настройки" to Icons.Default.Settings).forEach { (label, icon) ->
                NavigationBarItem(selected=page==label, onClick={page=label}, icon={Icon(icon, contentDescription=label)}, label={Text(label, fontSize=9.sp)}, colors=NavigationBarItemDefaults.colors(selectedIconColor=Purple, indicatorColor=Purple.copy(alpha=.18f)))
            }
        }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(top=16.dp,bottom=20.dp)) {
            item { when(page) {
                "Главная" -> {
                    CardBlock {
                        Text("ТВОЙ MINECRAFT", color=Purple, fontSize=12.sp, fontWeight=FontWeight.Bold)
                        Text("Играй по-своему.", fontSize=25.sp, fontWeight=FontWeight.ExtraBold)
                        Text("Java Edition • Android • Nova MB", color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                        Spacer(Modifier.height(10.dp)); Text("Ник игрока", fontWeight=FontWeight.SemiBold)
                        OutlinedTextField(value=nick, onValueChange={nick=it.take(16)}, singleLine=true, label={Text("Оффлайн-ник")}, modifier=Modifier.fillMaxWidth())
                        Button(onClick={onNickSave(nick);status="Ник сохранён"}, modifier=Modifier.fillMaxWidth()) { Text("Сохранить ник") }
                        Text("Выбранная версия: $selectedVersion", color=Purple)
                        Button(onClick={status="Среда запуска Minecraft Java ещё подключается. Это альфа-интерфейс."}, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Играть") }
                        Text(status, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.65f), fontSize=12.sp)
                    }
                    CardBlock { Text("БЫСТРЫЙ ДОСТУП", fontWeight=FontWeight.Bold); Text("Версии, сборки, управление и внешний вид — снизу.") }
                }
                "Версии" -> {
                    CardBlock {
                        Text("Версии Minecraft", fontSize=22.sp, fontWeight=FontWeight.Bold)
                        Text("Список загружается из официального манифеста Mojang.", color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f), fontSize=12.sp)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected=versionType=="release", onClick={versionType="release"}, label={Text("Релизы")})
                            FilterChip(selected=versionType=="snapshot", onClick={versionType="snapshot"}, label={Text("Снапшоты")})
                            FilterChip(selected=versionType=="all", onClick={versionType="all"}, label={Text("Все")})
                        }
                        Button(enabled=!loading, onClick={
                            loading=true; status="Получаю список версий…"
                        }, modifier=Modifier.fillMaxWidth()) { Text(if(loading) "Загрузка…" else "Обновить список версий") }
                        LaunchedEffect(loading) { if (loading) { try {
                            val result = withContext(Dispatchers.IO) {
                                val json=JSONObject(URL("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json").readText())
                                val arr=json.getJSONArray("versions"); val out= mutableListOf<String>()
                                for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); val t=o.getString("type"); if(versionType=="all" || t==versionType) out.add(o.getString("id")) }
                                out
                            }; versions=result; status="Найдено версий: ${result.size}"
                        } catch(e:Exception) { status="Не удалось загрузить: проверь интернет" } finally { loading=false } } }
                        versions.take(60).forEach { v -> Row(Modifier.fillMaxWidth().clickable { selectedVersion=v; status="Выбрана версия $v" }.padding(vertical=8.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Code, null, tint=Purple); Spacer(Modifier.width(10.dp)); Text(v, Modifier.weight(1f)); if(v==selectedVersion) Icon(Icons.Default.CheckCircle, null, tint=Purple) } }
                    }
                }
                "Сборки" -> CardBlock {
                    Text("Мои сборки", fontSize=22.sp, fontWeight=FontWeight.Bold)
                    Text("Профили сборок пока хранятся только в памяти этой сессии.", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                    packs.forEach { p -> Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Folder, null, tint=Purple); Spacer(Modifier.width(8.dp)); Text(p, Modifier.weight(1f)); if(p!="Чистый Minecraft") IconButton(onClick={packs=packs-p}) { Icon(Icons.Default.Delete, null) } } }
                    OutlinedTextField(value=packName, onValueChange={packName=it.take(40)}, label={Text("Название новой сборки")}, modifier=Modifier.fillMaxWidth())
                    Button(onClick={if(packName.isNotBlank() && packName !in packs) { packs=packs+packName.trim(); packName="" }}, modifier=Modifier.fillMaxWidth()) { Text("Создать профиль") }
                    Text("Импорт .mrpack, установка Fabric/Forge/NeoForge и управление модами — следующий этап.", fontSize=12.sp)
                }
                "Управление" -> CardBlock {
                    Text("Экранное управление", fontSize=22.sp, fontWeight=FontWeight.Bold)
                    Text("Набор кнопок для будущего игрового оверлея. Нажми ✕, чтобы убрать кнопку из макета.", fontSize=12.sp, color=MaterialTheme.colorScheme.onSurface.copy(alpha=.7f))
                    buttons.forEach { b -> Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.background, RoundedCornerShape(12.dp)).padding(start=12.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Gamepad, null, tint=Purple); Text(b, Modifier.weight(1f).padding(12.dp)); IconButton(onClick={buttons=buttons-b}) { Icon(Icons.Default.Close, null) } } }
                    Button(onClick={buttons=buttons+"Кнопка ${buttons.size+1}"}, modifier=Modifier.fillMaxWidth()) { Text("Добавить кнопку") }
                    Text("Привязка клавиш, перетаскивание кнопок и игровой оверлей заработают после подключения движка запуска.", fontSize=12.sp)
                }
                else -> CardBlock {
                    Text("Настройки Nova MB", fontSize=22.sp, fontWeight=FontWeight.Bold)
                    Row(verticalAlignment=Alignment.CenterVertically) { Text("Тёмная тема", Modifier.weight(1f)); Switch(checked=dark, onCheckedChange={dark=it;onTheme(it)}) }
                    Text("Цвет интерфейса")
                    listOf("Фиолетовый", "Синий", "Зелёный", "Красный").forEach { c -> FilterChip(selected=customColor==c, onClick={customColor=c}, label={Text(c)}) }
                    Text("Оффлайн-режим: ник без входа в аккаунт. Это не даёт доступ к серверам, требующим лицензионную авторизацию.", fontSize=12.sp)
                    Text("Nova Launcher MB 0.1.0-alpha", color=Purple, fontWeight=FontWeight.Bold)
                }
            } }
        }
    }
}

@Composable
private fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), content=content)
}
