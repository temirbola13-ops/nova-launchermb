# Nova Launcher MB — architecture decision (2026-10-26)

## Decision
Use **Amethyst-Android** as the initial game-launcher base, then rebrand and redesign its Android app as Nova Launcher MB. Do not try to embed its launcher engine into the current standalone Jetpack Compose prototype as a normal Gradle dependency: the upstream project includes native libraries, custom Java runtimes, LWJGL/GLFW integration, submodules and Android launch plumbing. Treating it as a library would require a major extraction project.

Upstream repository: https://github.com/AngelAuraMC/Amethyst-Android
Recommended branch per upstream build docs: `v3_openjdk`
Build task per upstream README: `:app_pojavlauncher:assembleDebug`

## Proposed layers

1. **Launcher engine (upstream Amethyst)**
   - Minecraft version metadata and game-file downloads
   - Java runtime selection and JVM startup
   - LWJGL, input pipeline, rendering backends and native libraries
   - Supported mod-loader setup (upstream documents Fabric and Forge)
2. **Nova MB product layer**
   - Branding, theme and navigation
   - Nickname/account screen; licensed account flow must remain available
   - Profiles/instances and modpack management
   - Touch-control editor and in-game overlay
   - Diagnostics, storage management and crash logs
3. **Integration boundary**
   - First make a branded build of the upstream app that still launches a game.
   - Then change one feature at a time, building and testing after each change.
   - Only extract engine APIs into separate modules if a later need is demonstrated.

## Why not just add a dependency?

The upstream build instructions call for a recursive clone, prebuilt JRE artifacts and a dedicated Gradle module. The engine is not published as a simple Android library. Native components and launch lifecycle need to stay consistent with upstream.

## License and redistribution checklist

Amethyst's README declares GNU LGPL v3. It also lists components with their own licenses, including OpenJDK, GL4ES, MobileGlues, LWJGL, SDL and other native libraries. Before distributing Nova MB:

- Keep the upstream license and copyright notices.
- Include the LGPL v3 license text and notices for all included components.
- Document source-code changes and provide the corresponding source/repository as required by the applicable licenses.
- Check the exact license of each submodule/native binary and any artifact bundled into the APK; do not assume the whole dependency tree has one license.
- Do not bundle Minecraft game assets or libraries in the APK unless their distribution is explicitly permitted. Download game files from official metadata at runtime and respect Minecraft's terms.
- Keep Microsoft/Mojang sign-in for services that require licensed authentication. An offline nickname is not a replacement for a licensed account.
- Do not imply Nova MB is an official Mojang/Microsoft product.

This is an engineering checklist, not legal advice. Verify current upstream files and all notices at the exact commit being used.

## References

- Amethyst Android source and build instructions: https://github.com/AngelAuraMC/Amethyst-Android
- Original PojavLauncher archive and successor notice: https://github.com/PojavLauncherTeam/PojavLauncher
- Amethyst installation/build guide: https://wiki.angelauramc.dev/wiki/getting_started/INSTALL

## Current prototype status

The `app/` Compose prototype is only a UI prototype. It can retrieve Mojang's version manifest and save a nickname/theme, but it does not install Minecraft assets, start a JVM, render the game, or implement a real touch overlay. The real-launch milestone requires the upstream engine to be present and tested first.
