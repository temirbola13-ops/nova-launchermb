# Nova Launcher MB — next implementation steps

## Milestone 1 — establish a working engine baseline
1. Clone `https://github.com/AngelAuraMC/Amethyst-Android.git` recursively, branch `v3_openjdk`.
2. Build the untouched upstream project using its documented command: `gradlew.bat :app_pojavlauncher:assembleDebug` on Windows.
3. Install and launch that APK on the target Android phone. Confirm a game can be launched before changing branding.
4. Save the exact upstream commit hash and license/submodule inventory in this repository.

## Milestone 2 — Nova MB branding without breaking launch
1. Change app label, icons, splash screen, theme resources and strings.
2. Keep engine, JNI, runtime files, launch intents and storage paths intact.
3. Build APK and test one vanilla version, one supported mod-loader instance, keyboard/mouse input and touch controls.

## Milestone 3 — product features
1. Persist profiles using Room or DataStore rather than Compose-only state.
2. Build a profile model containing game version, loader/version, Java runtime, JVM arguments, renderer and memory allocation.
3. Add safe import of `.mrpack`/supported archives with path validation and clear storage/error messages.
4. Add a touch-control editor with drag/resize, opacity, per-profile layouts and keyboard scancode mapping, integrating with the engine's input layer.
5. Add logs and crash reports that the user can inspect/export.

## Milestone 4 — verification
- Build in GitHub Actions for every push.
- Run lint/available unit tests.
- Keep a device test checklist for clean install, upgrade install, no network, insufficient storage, failed download/hash, game launch, pause/resume and crash recovery.

## Important
The current Compose prototype is not yet wired to a game engine. Do not label its Play button as functional until the engine integration has passed an actual device launch test.
